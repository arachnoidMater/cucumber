package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Stepdefinitions {
    private WebDriver driver;

    @Given("I am on the E-bebek homepage")
    public void navigateToHomepage() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\KÜBRA AYKAN\\selenium\\Chrome Driver\\chromedriver.exe"); // Chromedriver'ın dizinini belirtin
        driver = new ChromeDriver();
        driver.get("https://www.e-bebek.com/");
    }

    @When("I enter {string} into the search bar and click search")
    public void searchForProduct(String productName) {
        WebElement searchInput = driver.findElement(By.id("search"));
        searchInput.sendKeys(productName);
        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();
    }

    @When("I click on the first product")
    public void clickOnFirstProduct() {
        WebElement firstProduct = driver.findElement(By.xpath("//div[@class='product-list']//div[@class='product-card'][1]//a[@class='product-card__image-wrapper']"));
        firstProduct.click();
    }

    @When("I add the product to my cart")
    public void addToCart() {
        WebElement addToCartButton = driver.findElement(By.xpath("//button[contains(text(), 'Sepete Ekle')]"));
        addToCartButton.click();
    }

    @Then("I should see the product added to my cart")
    public void verifyProductAddedToCart() {
        WebElement cartIcon = driver.findElement(By.xpath("//span[@class='basket-icon']"));
        String cartItemCount = cartIcon.getText();
        System.out.println("Sepetimdeki ürün sayısı: " + cartItemCount);
        driver.quit();
    }
}


package pages;

public class EbebekPage {

    System.setProperty("webdriver.chrome.driver", "C:\\Users\\KÜBRA AYKAN\\selenium\\Chrome Driver\\chromedriver.exe");
    driver = new ChromeDriver();
    driver.get("https://www.e-bebek.com/");

}
